/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      72,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x08,
      27,   11,   11,   11, 0x08,
      41,   11,   11,   11, 0x08,
      63,   11,   11,   11, 0x08,
      81,   77,   11,   11, 0x08,
     105,   11,   11,   11, 0x08,
     118,   11,   11,   11, 0x08,
     137,   11,   11,   11, 0x08,
     161,   11,   11,   11, 0x08,
     183,   11,   11,   11, 0x08,
     199,   11,   11,   11, 0x08,
     230,  225,   11,   11, 0x08,
     257,   11,   11,   11, 0x08,
     272,   11,   11,   11, 0x08,
     301,   11,   11,   11, 0x08,
     327,   11,   11,   11, 0x08,
     357,   11,   11,   11, 0x08,
     384,   11,   11,   11, 0x08,
     397,   11,   11,   11, 0x08,
     414,   11,   11,   11, 0x08,
     431,  225,   11,   11, 0x08,
     462,   11,   11,   11, 0x08,
     474,   11,   11,   11, 0x08,
     497,  225,   11,   11, 0x08,
     524,  225,   11,   11, 0x08,
     552,   11,   11,   11, 0x08,
     568,   11,   11,   11, 0x08,
     601,  585,   11,   11, 0x08,
     643,   11,   11,   11, 0x08,
     657,   11,   11,   11, 0x08,
     670,   11,   11,   11, 0x08,
     690,   11,   11,   11, 0x08,
     699,   11,   11,   11, 0x08,
     713,   11,   11,   11, 0x08,
     725,   11,   11,   11, 0x08,
     733,   11,   11,   11, 0x08,
     757,   11,   11,   11, 0x08,
     780,   11,   11,   11, 0x08,
     813,   11,   11,   11, 0x08,
     838,  830,   11,   11, 0x08,
     859,   11,   11,   11, 0x0a,
     890,   11,   11,   11, 0x0a,
     922,  225,   11,   11, 0x0a,
     957,   11,   11,   11, 0x0a,
     971,   11,   11,   11, 0x0a,
     985,   11,   11,   11, 0x0a,
    1000,   11,   11,   11, 0x0a,
    1014,   11,   11,   11, 0x0a,
    1030,   11,   11,   11, 0x0a,
    1050,   11,   11,   11, 0x0a,
    1064,   11,   11,   11, 0x0a,
    1079,   11,   11,   11, 0x0a,
    1093,   11,   11,   11, 0x0a,
    1113,   11,   11,   11, 0x0a,
    1135,   11,   11,   11, 0x0a,
    1151,   11,   11,   11, 0x0a,
    1169,   11,   11,   11, 0x0a,
    1183,   11,   11,   11, 0x0a,
    1197,   11,   11,   11, 0x0a,
    1220,   11,   11,   11, 0x0a,
    1253,   11,   11,   11, 0x0a,
    1270,   11,   11,   11, 0x0a,
    1289,   11,   11,   11, 0x0a,
    1311, 1304,   11,   11, 0x0a,
    1329,   11,   11,   11, 0x0a,
    1349, 1344,   11,   11, 0x0a,
    1369,   11,   11,   11, 0x0a,
    1385,   11,   11,   11, 0x0a,
    1400,   11,   11,   11, 0x0a,
    1406,   11,   11,   11, 0x0a,
    1422,   11,   11,   11, 0x0a,
    1453,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0ShowCatalogs()\0SetAppStyle()\0"
    "ScanFolderForEbooks()\0AddNewBooks()\0"
    "pos\0ShowContextMenu(QPoint)\0RenameBook()\0"
    "MoveToNewCatalog()\0MoveToExistingCatalog()\0"
    "OpenThisBooksFolder()\0RenameCatalog()\0"
    "LoadThumbsOrGenerateOne()\0item\0"
    "OpenBook(QListWidgetItem*)\0OpenThisBook()\0"
    "OpenThisBookWithDefaultApp()\0"
    "OpenThisBookWithSomeApp()\0"
    "OpenBooksInDefaultAppOption()\0"
    "OpenBooksInThisAppOption()\0DeleteBook()\0"
    "DeleteBookDisk()\0BookProperties()\0"
    "CatalogClick(QListWidgetItem*)\0"
    "Favorites()\0FavoritesButtonClick()\0"
    "OneClick(QListWidgetItem*)\0"
    "BookClick(QListWidgetItem*)\0UnselectItems()\0"
    "SelectAllItems()\0item,isSelected\0"
    "SelectUnselectItem(QListWidgetItem*,bool)\0"
    "SetToolBar1()\0Connecting()\0"
    "SetProgressWidget()\0Status()\0HelpPDFMenu()\0"
    "HelpVideo()\0About()\0WatchFolderOpenDialog()\0"
    "WatchFolderSetFolder()\0"
    "WatchingFolderDirectoryChanged()\0"
    "WatchAndRemove()\0DirPath\0WatchAndAdd(QString)\0"
    "BackToAllCatalogsButtonClick()\0"
    "BackToThisCatalogsButtonClick()\0"
    "CatalogBookClick(QListWidgetItem*)\0"
    "eBookGoBack()\0eBookGoNext()\0eBookGoFirst()\0"
    "eBookGoLast()\0eBookGoToPage()\0"
    "eBookOriginalSize()\0eBookZoomIn()\0"
    "eBookZoomOut()\0SetOneStyle()\0"
    "SetScatteredStyle()\0SetFiveInOrderStyle()\0"
    "SetThreeStyle()\0SetInOrderStyle()\0"
    "SetExtStyle()\0SetTwoStyle()\0"
    "SetTwoScatteredStyle()\0"
    "CheckIfCatalogFilesStillExists()\0"
    "SettingsDialog()\0GetAvaiableSkins()\0"
    "FontFromMenu()\0number\0FontByNumber(int)\0"
    "SkinFromMenu()\0skin\0SkinByName(QString)\0"
    "writeSettings()\0readSettings()\0hit()\0"
    "FavoriteONOFF()\0CheckIfThereIsFavoritesOrNot()\0"
    "SetGridSizeByMenu()\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->ShowCatalogs(); break;
        case 1: _t->SetAppStyle(); break;
        case 2: _t->ScanFolderForEbooks(); break;
        case 3: _t->AddNewBooks(); break;
        case 4: _t->ShowContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 5: _t->RenameBook(); break;
        case 6: _t->MoveToNewCatalog(); break;
        case 7: _t->MoveToExistingCatalog(); break;
        case 8: _t->OpenThisBooksFolder(); break;
        case 9: _t->RenameCatalog(); break;
        case 10: _t->LoadThumbsOrGenerateOne(); break;
        case 11: _t->OpenBook((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 12: _t->OpenThisBook(); break;
        case 13: _t->OpenThisBookWithDefaultApp(); break;
        case 14: _t->OpenThisBookWithSomeApp(); break;
        case 15: _t->OpenBooksInDefaultAppOption(); break;
        case 16: _t->OpenBooksInThisAppOption(); break;
        case 17: _t->DeleteBook(); break;
        case 18: _t->DeleteBookDisk(); break;
        case 19: _t->BookProperties(); break;
        case 20: _t->CatalogClick((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 21: _t->Favorites(); break;
        case 22: _t->FavoritesButtonClick(); break;
        case 23: _t->OneClick((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 24: _t->BookClick((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 25: _t->UnselectItems(); break;
        case 26: _t->SelectAllItems(); break;
        case 27: _t->SelectUnselectItem((*reinterpret_cast< QListWidgetItem*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 28: _t->SetToolBar1(); break;
        case 29: _t->Connecting(); break;
        case 30: _t->SetProgressWidget(); break;
        case 31: _t->Status(); break;
        case 32: _t->HelpPDFMenu(); break;
        case 33: _t->HelpVideo(); break;
        case 34: _t->About(); break;
        case 35: _t->WatchFolderOpenDialog(); break;
        case 36: _t->WatchFolderSetFolder(); break;
        case 37: _t->WatchingFolderDirectoryChanged(); break;
        case 38: _t->WatchAndRemove(); break;
        case 39: _t->WatchAndAdd((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 40: _t->BackToAllCatalogsButtonClick(); break;
        case 41: _t->BackToThisCatalogsButtonClick(); break;
        case 42: _t->CatalogBookClick((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 43: _t->eBookGoBack(); break;
        case 44: _t->eBookGoNext(); break;
        case 45: _t->eBookGoFirst(); break;
        case 46: _t->eBookGoLast(); break;
        case 47: _t->eBookGoToPage(); break;
        case 48: _t->eBookOriginalSize(); break;
        case 49: _t->eBookZoomIn(); break;
        case 50: _t->eBookZoomOut(); break;
        case 51: _t->SetOneStyle(); break;
        case 52: _t->SetScatteredStyle(); break;
        case 53: _t->SetFiveInOrderStyle(); break;
        case 54: _t->SetThreeStyle(); break;
        case 55: _t->SetInOrderStyle(); break;
        case 56: _t->SetExtStyle(); break;
        case 57: _t->SetTwoStyle(); break;
        case 58: _t->SetTwoScatteredStyle(); break;
        case 59: _t->CheckIfCatalogFilesStillExists(); break;
        case 60: _t->SettingsDialog(); break;
        case 61: _t->GetAvaiableSkins(); break;
        case 62: _t->FontFromMenu(); break;
        case 63: _t->FontByNumber((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 64: _t->SkinFromMenu(); break;
        case 65: _t->SkinByName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 66: _t->writeSettings(); break;
        case 67: _t->readSettings(); break;
        case 68: _t->hit(); break;
        case 69: _t->FavoriteONOFF(); break;
        case 70: _t->CheckIfThereIsFavoritesOrNot(); break;
        case 71: _t->SetGridSizeByMenu(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 72)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 72;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
